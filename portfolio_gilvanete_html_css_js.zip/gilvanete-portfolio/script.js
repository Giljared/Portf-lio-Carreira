/* ===== Portfolio JS (vanilla) ===== */
(() => {
  const $ = (q, el=document) => el.querySelector(q);
  const $$ = (q, el=document) => [...el.querySelectorAll(q)];

  const toast = $("#toast");
  const themeToggle = $("#themeToggle");
  const menuBtn = $("#menuBtn");
  const mobileNav = $("#mobileNav");
  const closeMenu = $("#closeMenu");
  const copyEmail = $("#copyEmail");
  const copyEmail2 = $("#copyEmail2");
  const copyLinks = $("#copyLinks");
  const year = $("#year");
  const command = $("#command");
  const closeCmd = $("#closeCmd");

  // ---- Theme
  const THEME_KEY = "gs_theme";
  const applyTheme = (t) => {
    document.documentElement.setAttribute("data-theme", t);
    localStorage.setItem(THEME_KEY, t);
  };
  const initTheme = () => {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved) return applyTheme(saved);
    // prefer system
    const prefersLight = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
    applyTheme(prefersLight ? "light" : "dark");
  };

  // ---- Toast
  let toastTimer = null;
  const showToast = (msg) => {
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add("is-on");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-on"), 1500);
  };

  // ---- Clipboard helpers
  const copyText = async (text, okMsg="Copiado!") => {
    try{
      await navigator.clipboard.writeText(text);
      showToast(okMsg);
    } catch(e){
      // fallback
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      showToast(okMsg);
    }
  };

  // ---- Reveal on scroll
  const reveal = () => {
    const els = $$("[data-reveal]");
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) e.target.classList.add("is-in");
      });
    }, { threshold: 0.12 });
    els.forEach(el => io.observe(el));
  };

  // ---- Projects
  const projects = [
    {
      title: "Dashboard de Integrações (JS)",
      desc: "Painel simples para visualizar status de integrações e logs locais (foco em UI + DOM).",
      tags: ["js","ui"],
      repo: "https://github.com/Giljared",
      live: "#"
    },
    {
      title: "Consumidor de API (fetch)",
      desc: "Projeto demonstrando consumo de API, tratamento de erros e renderização em cards.",
      tags: ["js","api"],
      repo: "https://github.com/Giljared",
      live: "#"
    },
    {
      title: "Automação de Formulários",
      desc: "Validação, máscaras e envio (simulado) com feedback e UX clara.",
      tags: ["js","automation","ui"],
      repo: "https://github.com/Giljared",
      live: "#"
    },
    {
      title: "To-do com Persistência (localStorage)",
      desc: "CRUD completo com filtros, persistência e organização de código.",
      tags: ["js"],
      repo: "https://github.com/Giljared",
      live: "#"
    },
    {
      title: "Landing Responsiva (HTML/CSS)",
      desc: "Layout moderno, acessível e responsivo, com seções e componentes reutilizáveis.",
      tags: ["ui"],
      repo: "https://github.com/Giljared",
      live: "#"
    },
    {
      title: "Mapeamento de Dados (ETL simples)",
      desc: "Script JS para transformar dados (arrays/objects) e gerar saída formatada.",
      tags: ["js","automation"],
      repo: "https://github.com/Giljared",
      live: "#"
    }
  ];

  const renderProjects = (filter="all") => {
    const grid = $("#projectGrid");
    if (!grid) return;
    grid.innerHTML = "";
    const filtered = filter === "all" ? projects : projects.filter(p => p.tags.includes(filter));

    filtered.forEach((p) => {
      const card = document.createElement("article");
      card.className = "pcard";
      card.setAttribute("data-tags", p.tags.join(","));
      card.innerHTML = `
        <div class="pcard__top">
          <div>
            <div class="pcard__t">${p.title}</div>
            <div class="pcard__d">${p.desc}</div>
          </div>
          <div class="bad" title="Tipo">★</div>
        </div>
        <div class="pcard__tags">
          ${p.tags.map(t => `<span class="bad">#${t}</span>`).join("")}
        </div>
        <div class="pcard__actions">
          <a class="btn btn--mini btn--primary" href="${p.repo}" target="_blank" rel="noreferrer">Repo</a>
          <a class="btn btn--mini btn--ghost" href="${p.live}" target="_blank" rel="noreferrer">Demo</a>
        </div>
      `;
      grid.appendChild(card);
    });

    showToast(`${filtered.length} projeto(s) exibido(s)`);
  };

  const initFilters = () => {
    const buttons = $$("[data-filter]");
    if (!buttons.length) return;
    buttons.forEach((b) => {
      b.addEventListener("click", () => {
        buttons.forEach(x => x.classList.remove("is-active"));
        b.classList.add("is-active");
        renderProjects(b.dataset.filter);
      });
    });
  };

  // ---- Mobile menu
  const openMenu = () => {
    mobileNav?.classList.add("is-on");
    mobileNav?.setAttribute("aria-hidden", "false");
  };
  const closeMenuFn = () => {
    mobileNav?.classList.remove("is-on");
    mobileNav?.setAttribute("aria-hidden", "true");
  };

  // ---- Command palette (shortcuts)
  const openCmd = () => {
    command?.classList.add("is-on");
    command?.setAttribute("aria-hidden","false");
  };
  const closeCmdFn = () => {
    command?.classList.remove("is-on");
    command?.setAttribute("aria-hidden","true");
  };

  // ---- Smooth scroll for anchor links
  const initAnchors = () => {
    $$('a[href^="#"]').forEach((a) => {
      a.addEventListener("click", (e) => {
        const href = a.getAttribute("href");
        if (!href || href === "#") return;
        const id = href.slice(1);
        const target = document.getElementById(id);
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
        closeMenuFn();
      });
    });
  };

  // ---- Init
  const init = () => {
    initTheme();
    reveal();
    initAnchors();
    renderProjects("all");
    initFilters();

    if (year) year.textContent = new Date().getFullYear();

    themeToggle?.addEventListener("click", () => {
      const cur = document.documentElement.getAttribute("data-theme") || "dark";
      applyTheme(cur === "dark" ? "light" : "dark");
      showToast(cur === "dark" ? "Tema claro" : "Tema escuro");
    });

    menuBtn?.addEventListener("click", openMenu);
    mobileNav?.addEventListener("click", (e) => {
      if (e.target === mobileNav) closeMenuFn();
    });
    closeMenu?.addEventListener("click", closeMenuFn);
    $$(".mobileNav__link").forEach(l => l.addEventListener("click", closeMenuFn));

    const email = "gmat337@gmail.com";
    copyEmail?.addEventListener("click", () => copyText(email, "E-mail copiado"));
    copyEmail2?.addEventListener("click", () => copyText(email, "E-mail copiado"));

    copyLinks?.addEventListener("click", () => {
      const links = [
        "LinkedIn: https://www.linkedin.com/in/gilvanete-silva/",
        "GitHub: https://github.com/Giljared"
      ].join("\n");
      copyText(links, "Links copiados");
    });

    // keyboard shortcuts
    document.addEventListener("keydown", (e) => {
      const key = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && key === "k") {
        e.preventDefault();
        const isOn = command?.classList.contains("is-on");
        isOn ? closeCmdFn() : openCmd();
      }
      if (key === "t" && !e.ctrlKey && !e.metaKey) {
        // ignore if typing
        const tag = (document.activeElement?.tagName || "").toLowerCase();
        if (tag === "input" || tag === "textarea") return;
        themeToggle?.click();
      }
      if (key === "e" && !e.ctrlKey && !e.metaKey) {
        const tag = (document.activeElement?.tagName || "").toLowerCase();
        if (tag === "input" || tag === "textarea") return;
        copyText(email, "E-mail copiado");
      }
      if (key === "escape") {
        closeMenuFn();
        closeCmdFn();
      }
    });

    closeCmd?.addEventListener("click", closeCmdFn);
    command?.addEventListener("click", (e) => {
      if (e.target === command) closeCmdFn();
    });
  };

  window.addEventListener("DOMContentLoaded", init);
})();
